//! Anonymous functions

// function without parameter and without return type

let fun= function (){
    console.log("hello this is anonymous funcions")
}
fun()

// function with parameter and without return type
let fun1= function (b){
    console.log(b)
}
fun1(12)

// function without parameter and with return type
let fun3= function (){
    return 30
}
let z=fun3()
console.log(z)


// function with parameter and with return type
let user= function (from){
    console.log("hello from"+from)
}
let k=user("smijul")
// console.log(user)

//!anomysous functions
// Even or odd
let evenodd=function(number){
    if(number%2==0){
        console.log("even number")
    }
    else{
        console.log("odd number")
    }
}
evenodd(121)

//sum of 2 numbers
let sumnumber=function(num1,num2){
    return num1+num2

}
sum=sumnumber(10,20)
console.log(sum)

// printing from 1 to 10
let print=function (pnumber){
    for(let i=0;i<=pnumber;i++){
        console.log(i)
    }
}
print(10)

