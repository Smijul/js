function demo(a,b,c){
    console.log(a,b,c)
}
demo("dinga")

// Function2
function fun(){
    let x=true;
    return x
}
let y=fun()
console.log(y)

// question wap to check even or odd number by using geeneral function with return value

function evenorodd(){
    let x=23
    if(x%2==0){
        return true
    }
    else{
        return false
    }
}
let value=evenorodd()
console.log(value)

value==true?console.log("even"):console.log("odd")

// another way
function evenodd2(){
    let num=12
    return (num==0)? `${num} is Even number`: `${num} is Odd number`
}
let res=evenodd2()
console.log(res)

//function with paara nd with return type
function wpwr(user){    
    return("hello "+user)
}
let res1=wpwr("smijul")
console.log(res1)

// evenodd

function evenodd(number){

    return number%2==0?`${number} is even`:`${number} is odd`
}
let res2=evenodd(201)
console.log(res2)

// wap to add 2 numbers by using general function with parameter and return value

function adding(number1,number2){
    return number1+number2
}
console.log(adding(53,23))

// CHANGING THE DEFAULT VALUES

function addNumber(a=Number(),b=Number()){
    let sum=a+b
    return `${a}+ ${b} =${sum}`
}   
let s1=addNumber(10,20)
console.log(s1)

console.log(addNumber(20,50))   
addNumber()