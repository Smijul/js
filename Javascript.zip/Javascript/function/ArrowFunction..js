// ! ARROW FUNCTION



// ()=>{  
// }

// FUNCTION WITHOUT PARAMTER WITHOUT RETURN TYPE
let arrow1= ()=>{
    console.log("this is arrow function without paaramter withour return type")
}
arrow1()

// FUNCTION WITHOUT PARAMTER WITHOUT WITH RETRUN TYPE
let arrow2=()=>{
    return "hai"
}
let result2=arrow2();
console.log(result2)

//FUNTION WITH PARAMETER WITHOUT RETURN TYPE
let arrrow3=(num1,num2)=>{
    console.log(num1+num2)
}
let sum3=arrrow3(10,20)

//FUNTION WITH PARAMETER WITH RETURN TYPE
let arrrow4=(num1,num2)=>{
    return num1+num2
}
let sum4=arrrow4(10,20)
console.log(sum4)

// wap to check even or odd number by susing arrow function with parameter and return value
let evenodd=(num5)=>{
    if(num5%2==0){
        return "even"
    }
    else{
        return "odd"
    }
}
let sum5=evenodd(24)
console.log(sum5)

// swapping 2 number

//TODO:Special behavior of arrow function

let sparrow1= _ =>{
    console.log("special one")
}
sparrow1()

let sparrow2 = _=> console.log("special 2")
sparrow2()

let sparrow3=num=>{
    console.log("hai"+num)
}
sparrow3(100)

let add=(a,b)=>`${a} + ${b} = ${a+b}`
let res=add(20,30)
console.log(res)