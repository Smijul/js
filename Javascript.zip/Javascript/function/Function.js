//!FUNCTIONS

// todo function without parameter & without return type
console.warn("without parameter & without return type")
function fun(){
    console.log("Hello")
}
fun()
function add(){
    let a=5
    let b=10
    sum=a+b
    console.log(sum)
}
add()

//function with parameter and no return value
console.warn("function with parameter and no return value")

function adding(a,b){
    sum =a+b
    console.log(`${a} + ${b} = ${sum}`)
}
adding(10,20)
adding(100,200)

//wap to check number is even or odd using function
console.warn("number is even or odd using function")

function evenorodd(a){
    if(a%2==0){
        console.log(`${a} even number`)
    }
    else if(a%2!=0){
        console.log(`${a} odd number`)
    }
    else{   
        console.log("not belong to number")
    }
}

evenorodd(121)


//wap to print even numbers from 25 to 35 by using general funtion with parameter


console.warn("print even numbers from 25 to 35 with parameter")
function evennumber(a ,b){
    for(let i=a;i<=b;i++){
        if(i%2==0){
            console.log(`${i} is even number`)
        }
    }
}
evennumber(25,35)

//wap to print even numbers from 25 to 35 by using general funtion with parameter

console.warn("print odd numbers from 25 to 35 with parameter")
function oddnumber(a ,b){
    for(let i=a;i<=b;i++){
        if(i%2!=0){
            console.log(`${i} is odd number`)
        }
    }
}
oddnumber(25,35)

//cahnging the default values
console.warn("changinig the defalut values whwen erver we are not  passsing anything")
function demo(x=true){
    console.log(x)
}
demo(1)
demo('hi')
demo(undefined)
demo(null)


