console.log("Even number from 1 to 25 by while")
let l=1
while(l<=25){
    if(l%2==0){
        console.log(l)
    }
    l++
}


console.log("Odd number between 60 and 70")
let i=60
while(i<=70){
    
    if(i%2!=0){
        console.log(i)

    }
    i++
}

console.log("Even number between 15 and 25")
for(let j=25;j>=15;j--){
    if(j%2==0){
        console.log(j)
    }
}

console.log("odd number between 60 and 70")
for(let k=60;k<=70;k++){
    if(k%2!=0){
        console.log(k)
    }
}