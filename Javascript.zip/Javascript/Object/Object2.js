// !Creating object by using new keyword

let Car=new Object()
console.log(Car)
console.log(typeof Car)


Car.carName="bmw"
Car.color="blue"
console.log(Car)

// let n=Number()
// console.log(n)
// console.log(typeof n)

//todo: Date object

let d=new Date()
console.log(d)
console.log(typeof d)

console.log("Date is"+d.getDate())
console.log("Month is "+d.getMonth())
console.log("Year is "+d.getFullYear())

console.log("hours"+d.getHours())
console.log("Minutes"+d.getHours())
console.log("seconds"+d.getSeconds())