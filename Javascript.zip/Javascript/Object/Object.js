//! 1 directly creating object
//! 2 by isng new keyword
Car={
    CarName:"bmw",
    Model:"Q8",
    price:2340000
}
console.log(Car)
console.log(typeof object)

// todo: Accessing the property from object

//! we can access the object by 2 ways 
// !  .operatre ,subscript operator [" "]

// ?by dot operator6
console.log(Car.Model)

// ? by using subscrpt operator
console.log(Car["CarName"])


// !Modifications
// todo: updating the object property
// ?ObjeactName.propertyName="new vlue"
Car.CarName="lambogini"
console.log(Car)

// todo:adding the new property to object
// ?ObjectName.newPropery="new value"
Car.Color="black"
console.log(Car)
console.log(Car)

// todo:deleting the property from object
// ? delete(keyword) objectanme.propertyname
delete Car.Model
console.log(Car)

// ! Accessing the Nested object property

let person={
    name:"smijul",
    age:25,
    address:{
        state:"Kerala",
        district:"kannur",
        pin:670692
    }
}
// todo: Accessing the property  ------------------------------------>
console.log(person.name)

// todo: Accessing the nested object--------------------------------->
console.log(person.address.state)

// example
console.log(`${person.name} is from ${person.address.state}`)
console.log(`${person.name} age is ${person.age}`)

// todo example program 1--------------------------------------->
let student={
    fname:"dinga",
    lname:"raja",
    place:"goa",
    dob:1999,
    calculateAge:function(){
        let age=2025-this.dob
        console.log(`${this.fname} is from ${student.place}`)
    }
}

console.log(`${student.fname} is from ${student.place}`)
student.calculateAge()

console.log(typeof(100)-typeof("hi"))



