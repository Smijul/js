// Var keyword

var a  //decleration
a =10;   //initilization
console.log(a)   
a=20   //reintialization
console.log(a)
a='hai'   //reinit
console.log(a)
var a=2.5  //re-declr
console.log(a)


let i //declearation
i=10 ; //initialization
console.log(i)
i='hello'  //reinitialization
console.log(i)

// let i='hai redecleration is not possible in the keyword of let

const c='hai by const'
// c=20;  not allowed
console.log(c)


//Data types
let n=10
console.log(n)  //10
console.log(typeof n)  //number

let s='hello'
console.log(s)  //hello
console.log(typeof s)  //string

let b=true
console.log(b)  //true
console.log(typeof n)  //boolean

let u=undefined
console.log(b)//undefined
console.log(typeof b)//undefined

let m=null
console.log(m)//null
console.log(typeof m) //object



let n1=Number(1000)
console.log(n1)  //1000
console.log(typeof n1)  //number

// let n2=number('a')  
// console.log(n2) //NAN
// console.log(typeof n2)  //number

let n3=Number(true)
console.log(n3)
console.log(typeof n3)

let n4=Number(false)
console.log(n4)

