console.warn("This is warning")
console.error("this is error in console")
// alert("Alert broo")

var a=12
var b=20
var c=a+b;
console.log(c);

let u=undefined;
console.log(u);
console.log(typeof u);
console.log(9%2);   
console.log(typeof(NaN));
let n2=Number('a')
console.log(n2)
let n3=Number(false);
console.log(n3);
