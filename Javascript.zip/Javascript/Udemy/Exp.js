let num=10
console.log(num)
console.log(typeof num)
// todo
console.log("********************");
let s="hello"
console.log(s)
console.log(typeof s)
console.log("********************");
let b=true
console.log(b)
console.log(typeof b)
console.log(typeof s)
console.log("********************");
let u=undefined
console.log(u)
console.log(typeof u)
console.log(typeof s)
console.log("********************")
let n=null
console.log(n)
console.log(typeof n)
console.log("********************")
let n1=Number(1000)
console.log(n1)
console.log(typeof n1)
console.log("********************")
let n2=Number('a')
console.log(n2)
console.log(typeof n2)
console.log("********************")
let n3=Number(true)
console.log(n3)
console.log(typeof n3)
console.log("********************")
let n4=Number(undefined)
console.log(n4)
console.log(typeof n4)
console.log("********************")
let n5=Number(null)
console.log(n5)
console.log(typeof n5)
console.log("********************")
let s1=String('hi')
console.log(s1)
console.log(typeof s1)
console.log("********************")
let s2=String(undefined)
console.log(s2)
console.log(typeof s2)
console.log("********************")
let c=true
console.log(b)
console.log(typeof b)
console.log("********************")
let d=Boolean('hi')
console.log(d)
console.log(typeof d)



