// !self invoking function
// (function fun(){
//     console.log("self invoking functions 1");
// }())



// (function fun1(){
//     console.log("self invoking functions 2")
// })()

(function fun2() {
    console.log("self invoking function 3")
})()


// !Call back function 
let num = () => {
    return 100
}

let sum = (a, b) => {    //accepting the call back function is  called  is higher order function
    let add = a + b
    console.log(add)
}
sum(num(), 200)       //as argument i can call create function is called 




let sum1 = (a, b) => {    //here sum is higher order function
    let add = a + b
    console.log(add)
}
sum1(() => {
    return 100
}, 200)  

// !Call back funcion second days

console.warn("call back function second day")
let surname= ()=>{
    return "ek"
}

let fullname=(fnm,lnm)=>{
    console.log(`my name is ${fnm} ${lnm}`)
}
// ?here if aimcalling surename() it is returning the value
fullname("smijul",surname())

// ? Here if aim calling anthis surename without methode it will give the entire code
fullname("smijul",surname)

// !Higher order functions