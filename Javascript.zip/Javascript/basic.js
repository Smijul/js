//document print statement
document.write("Hello")
document.writeln("give spaces")

document.writeln("<br>")

document.writeln("welcome")
document.writeln("javascript")

document.writeln("<h1 style=color:red>html tage i cn use in the js but need to put </h1>")

//todo: console print statements
console.log("Welcome")
console.log("to") 
console.log("My class")

console.warn("warning")

console.error("warning")

console.log("<h1>Hei</h1>")


//pop up message

alert("This is one pop up message by alert")